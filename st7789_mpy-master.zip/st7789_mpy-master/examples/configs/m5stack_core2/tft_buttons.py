
# input pins for M5Stack Core2 buttons

from machine import Pin


class Buttons():
    def __init__(self):
        self.name = "m5stack_core2"
